$(document).ready(function () {
  const life = document.querySelectorAll(".life");
  const life_li = document.querySelectorAll(".life li");
  const lifeContent = document.querySelectorAll(".lifeContent ul");

  $(life_li).mouseenter(function () {
    idx = $(this).index();
    addStyle(idx);
    // console.log(idx);
  });

  function addStyle(idx) {
    console.log(idx);
    $(life_li).removeClass("on");
    $(life_li[idx]).addClass("on");
    $(lifeContent).css("display", "none");
    $(lifeContent[idx]).css("display", "flex");
  }

  function showContent() {}
});
